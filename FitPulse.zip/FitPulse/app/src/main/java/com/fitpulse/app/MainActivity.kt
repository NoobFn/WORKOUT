package com.fitpulse.app

import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.FitnessCenter
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val store = Store(applicationContext)
        setContent {
            FitTheme {
                Surface(Modifier.fillMaxSize(), color = Bg) {
                    App(store)
                }
            }
        }
    }
}

@Composable
fun App(store: Store) {
    var history by remember { mutableStateOf(store.load()) }
    var tab by remember { mutableIntStateOf(0) }
    var detail by remember { mutableStateOf<Routine?>(null) }
    var active by remember { mutableStateOf<Routine?>(null) }

    val a = active
    val d = detail

    if (a != null) {
        ActiveWorkout(
            routine = a,
            onExit = { active = null },
            onSave = { session ->
                store.add(session)
                history = store.load()
                active = null
                detail = null
                tab = 2
            }
        )
    } else if (d != null) {
        BackHandler { detail = null }
        RoutineDetail(routine = d, onBack = { detail = null }, onStart = { active = d })
    } else {
        Scaffold(
            containerColor = Bg,
            bottomBar = {
                NavigationBar(containerColor = Panel) {
                    val items = listOf(
                        Triple("Home", Icons.Rounded.Home, 0),
                        Triple("Workouts", Icons.Rounded.FitnessCenter, 1),
                        Triple("History", Icons.Rounded.History, 2)
                    )
                    items.forEach { (label, icon, index) ->
                        NavigationBarItem(
                            selected = tab == index,
                            onClick = { tab = index },
                            icon = { Icon(icon, contentDescription = label) },
                            label = { Text(label) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Accent,
                                selectedTextColor = Accent,
                                indicatorColor = Accent.copy(alpha = 0.18f),
                                unselectedIconColor = Muted,
                                unselectedTextColor = Muted
                            )
                        )
                    }
                }
            }
        ) { pad ->
            when (tab) {
                0 -> HomeScreen(history, pad) { detail = it }
                1 -> WorkoutsScreen(pad) { detail = it }
                else -> HistoryScreen(history, pad)
            }
        }
    }
}
