package com.fitpulse.app

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Bg = Color(0xFF0B0B12)
val Panel = Color(0xFF16161F)
val Panel2 = Color(0xFF222230)
val Accent = Color(0xFFFF5A36)
val Accent2 = Color(0xFFFFB02E)
val Muted = Color(0xFF8D8DA3)

@Composable
fun FitTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Accent,
            onPrimary = Color.White,
            secondary = Accent2,
            background = Bg,
            onBackground = Color.White,
            surface = Panel,
            onSurface = Color.White,
            surfaceVariant = Panel2,
            onSurfaceVariant = Muted
        ),
        content = content
    )
}
