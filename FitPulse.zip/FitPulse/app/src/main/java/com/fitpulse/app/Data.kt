package com.fitpulse.app

import android.content.Context
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.DirectionsRun
import androidx.compose.material.icons.rounded.FitnessCenter
import androidx.compose.material.icons.rounded.LocalFireDepartment
import androidx.compose.material.icons.rounded.SelfImprovement
import androidx.compose.material.icons.rounded.Whatshot
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

data class Exercise(
    val name: String,
    val sets: Int,
    val amount: Int,
    val unit: String,
    val rest: Int,
    val tip: String
)

data class Routine(
    val id: String,
    val name: String,
    val tagline: String,
    val level: String,
    val c1: Color,
    val c2: Color,
    val icon: ImageVector,
    val exercises: List<Exercise>
) {
    val minutes: Int get() = (exercises.sumOf { it.sets * (40 + it.rest) } / 60).coerceAtLeast(5)
    val totalSets: Int get() = exercises.sumOf { it.sets }
}

private fun ex(name: String, sets: Int, amount: Int, unit: String = "reps", rest: Int = 45, tip: String = "") =
    Exercise(name, sets, amount, unit, rest, tip)

object Library {
    val all: List<Routine> = listOf(
        Routine(
            "push", "Push Day", "Chest, shoulders and triceps", "Intermediate",
            Color(0xFFFF5A36), Color(0xFFFFB02E), Icons.Rounded.FitnessCenter,
            listOf(
                ex("Push-ups", 4, 12, tip = "Body in one straight line"),
                ex("Pike Push-ups", 3, 10, tip = "Hips high, head toward the floor"),
                ex("Chair Dips", 3, 12, tip = "Keep elbows pointing back"),
                ex("Diamond Push-ups", 3, 10, tip = "Hands close, elbows tucked"),
                ex("Plank Shoulder Taps", 3, 20, tip = "Don't let your hips rock")
            )
        ),
        Routine(
            "legs", "Leg Day", "Quads, glutes and calves", "Intermediate",
            Color(0xFF7C4DFF), Color(0xFF00B0FF), Icons.Rounded.DirectionsRun,
            listOf(
                ex("Squats", 4, 15, tip = "Chest up, knees over toes"),
                ex("Alternating Lunges", 3, 12, tip = "Drop the back knee straight down"),
                ex("Glute Bridges", 3, 15, tip = "Squeeze hard at the top"),
                ex("Jump Squats", 3, 10, rest = 60, tip = "Land soft"),
                ex("Wall Sit", 3, 40, "sec", 45, "Thighs parallel to the floor"),
                ex("Calf Raises", 3, 20, rest = 30, tip = "Slow on the way down")
            )
        ),
        Routine(
            "core", "Core Crusher", "Abs and obliques", "Beginner",
            Color(0xFF00C853), Color(0xFF00E5FF), Icons.Rounded.Bolt,
            listOf(
                ex("Crunches", 3, 20, rest = 30, tip = "Lift with your abs, not your neck"),
                ex("Plank", 3, 45, "sec", 30, "Squeeze glutes and brace"),
                ex("Bicycle Crunches", 3, 20, rest = 30, tip = "Slow and controlled"),
                ex("Leg Raises", 3, 12, tip = "Lower back stays on the floor"),
                ex("Mountain Climbers", 3, 30, "sec", 30, "Drive knees fast"),
                ex("Russian Twists", 3, 20, rest = 30, tip = "Rotate from the ribs")
            )
        ),
        Routine(
            "hiit", "HIIT Burn", "Fast and sweaty fat burner", "Advanced",
            Color(0xFFFF1744), Color(0xFFFF9100), Icons.Rounded.LocalFireDepartment,
            listOf(
                ex("Burpees", 4, 10, rest = 30, tip = "Explode up every rep"),
                ex("High Knees", 4, 30, "sec", 20, "Knees to hip height"),
                ex("Jumping Jacks", 4, 40, rest = 20, tip = "Stay light on your feet"),
                ex("Skater Jumps", 4, 16, rest = 30, tip = "Big lateral bounds"),
                ex("Mountain Climbers", 4, 30, "sec", 30, "Don't let your hips rise")
            )
        ),
        Routine(
            "full", "Full Body", "One session, every muscle", "Intermediate",
            Color(0xFF2979FF), Color(0xFF7C4DFF), Icons.Rounded.Whatshot,
            listOf(
                ex("Squats", 3, 15, tip = "Full depth if you can"),
                ex("Push-ups", 3, 12, tip = "Chest to the floor"),
                ex("Reverse Lunges", 3, 10, tip = "Step back, stay tall"),
                ex("Superman Hold", 3, 12, tip = "Pause for a second at the top"),
                ex("Plank", 3, 40, "sec", 30, "Straight line head to heels")
            )
        ),
        Routine(
            "stretch", "Stretch & Mobility", "Cool down and loosen up", "Beginner",
            Color(0xFF00BFA5), Color(0xFF64FFDA), Icons.Rounded.SelfImprovement,
            listOf(
                ex("Cat-Cow", 2, 10, rest = 10, tip = "Move with your breath"),
                ex("Child's Pose", 2, 30, "sec", 10, "Sink hips toward heels"),
                ex("Hamstring Stretch", 2, 30, "sec", 10, "Soft knee, long spine"),
                ex("Hip Opener", 2, 30, "sec", 10, "Don't force it"),
                ex("Shoulder Rolls", 2, 15, rest = 10, tip = "Big slow circles")
            )
        )
    )
}

data class Session(val routine: String, val minutes: Int, val sets: Int, val at: Long)

class Store(context: Context) {
    private val prefs = context.getSharedPreferences("fitpulse", Context.MODE_PRIVATE)

    fun load(): List<Session> {
        val raw = prefs.getString("history", null) ?: return emptyList()
        return try {
            val a = JSONArray(raw)
            (0 until a.length()).map {
                val o = a.getJSONObject(it)
                Session(o.getString("r"), o.getInt("m"), o.getInt("s"), o.getLong("t"))
            }.sortedByDescending { it.at }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun add(s: Session) {
        val a = JSONArray()
        (listOf(s) + load()).take(300).forEach {
            a.put(JSONObject().put("r", it.routine).put("m", it.minutes).put("s", it.sets).put("t", it.at))
        }
        prefs.edit().putString("history", a.toString()).apply()
    }
}

fun dayKey(ms: Long): Long {
    val c = Calendar.getInstance()
    c.timeInMillis = ms
    c.set(Calendar.HOUR_OF_DAY, 0)
    c.set(Calendar.MINUTE, 0)
    c.set(Calendar.SECOND, 0)
    c.set(Calendar.MILLISECOND, 0)
    return c.timeInMillis
}

fun weekStart(): Long {
    val c = Calendar.getInstance()
    c.firstDayOfWeek = Calendar.MONDAY
    c.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY)
    return dayKey(c.timeInMillis)
}

fun streak(history: List<Session>): Int {
    val days = history.map { dayKey(it.at) }.toSet()
    val c = Calendar.getInstance()
    var key = dayKey(c.timeInMillis)
    if (key !in days) {
        c.add(Calendar.DAY_OF_YEAR, -1)
        key = dayKey(c.timeInMillis)
        if (key !in days) return 0
    }
    var n = 0
    while (key in days) {
        n++
        c.add(Calendar.DAY_OF_YEAR, -1)
        key = dayKey(c.timeInMillis)
    }
    return n
}
