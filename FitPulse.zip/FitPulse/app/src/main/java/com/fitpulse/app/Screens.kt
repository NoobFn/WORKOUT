package com.fitpulse.app

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.EmojiEvents
import androidx.compose.material.icons.rounded.FitnessCenter
import androidx.compose.material.icons.rounded.LocalFireDepartment
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.Timer
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

// ---------- Shared building blocks ----------

@Composable
fun GradientButton(
    text: String,
    colors: List<Color>,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    onClick: () -> Unit
) {
    Box(
        modifier
            .height(60.dp)
            .clip(RoundedCornerShape(20.dp))
            .background(Brush.horizontalGradient(colors))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (icon != null) Icon(icon, null, tint = Color.White)
            Text(text, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun Pill(text: String) {
    Box(
        Modifier
            .clip(RoundedCornerShape(50))
            .background(Color.White.copy(alpha = 0.2f))
            .padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
        Text(text, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun SectionTitle(text: String) {
    Text(text, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 12.dp))
}

@Composable
fun RoutineCard(r: Routine, modifier: Modifier = Modifier, height: Dp = 150.dp, onClick: () -> Unit) {
    Box(
        modifier
            .height(height)
            .clip(RoundedCornerShape(26.dp))
            .background(Brush.linearGradient(listOf(r.c1, r.c2)))
            .clickable(onClick = onClick)
    ) {
        Icon(
            r.icon, null,
            tint = Color.White.copy(alpha = 0.18f),
            modifier = Modifier
                .size(height * 0.9f)
                .align(Alignment.BottomEnd)
                .offset(x = 20.dp, y = 20.dp)
        )
        Column(
            Modifier
                .fillMaxSize()
                .padding(20.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(r.name, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
                Text(r.tagline, color = Color.White.copy(alpha = 0.85f), fontSize = 13.sp)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Pill("${r.minutes} min")
                Pill(r.level)
                Pill("${r.exercises.size} moves")
            }
        }
    }
}

@Composable
fun StatCard(icon: ImageVector, value: String, label: String, tint: Color, modifier: Modifier = Modifier) {
    Column(
        modifier
            .clip(RoundedCornerShape(20.dp))
            .background(Panel)
            .padding(16.dp)
    ) {
        Box(
            Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(tint.copy(alpha = 0.18f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, null, tint = tint, modifier = Modifier.size(20.dp))
        }
        Spacer(Modifier.height(12.dp))
        Text(value, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text(label, color = Muted, fontSize = 12.sp)
    }
}

@Composable
fun Ring(progress: Float, diameter: Dp, stroke: Dp, content: @Composable BoxScope.() -> Unit) {
    val p by animateFloatAsState(progress.coerceIn(0f, 1f), tween(900, easing = LinearEasing), label = "ring")
    Box(Modifier.size(diameter), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val s = stroke.toPx()
            val arcSize = Size(this.size.width - s, this.size.height - s)
            val topLeft = Offset(s / 2, s / 2)
            drawArc(
                color = Panel2, startAngle = -90f, sweepAngle = 360f, useCenter = false,
                topLeft = topLeft, size = arcSize, style = Stroke(s, cap = StrokeCap.Round)
            )
            if (p > 0f) {
                drawArc(
                    brush = Brush.linearGradient(listOf(Accent2, Accent)),
                    startAngle = -90f, sweepAngle = 360f * p, useCenter = false,
                    topLeft = topLeft, size = arcSize, style = Stroke(s, cap = StrokeCap.Round)
                )
            }
        }
        content()
    }
}

// ---------- Home ----------

@Composable
fun HomeScreen(history: List<Session>, pad: PaddingValues, onOpen: (Routine) -> Unit) {
    val pick = remember {
        Library.all[Calendar.getInstance().get(Calendar.DAY_OF_WEEK) % Library.all.size]
    }
    val start = remember { weekStart() }
    val week = history.filter { it.at >= start }

    LazyColumn(
        contentPadding = PaddingValues(
            start = 20.dp, end = 20.dp,
            top = pad.calculateTopPadding() + 24.dp,
            bottom = pad.calculateBottomPadding() + 24.dp
        ),
        verticalArrangement = Arrangement.spacedBy(24.dp)
    ) {
        item {
            Column {
                Text(
                    SimpleDateFormat("EEEE, MMM d", Locale.getDefault()).format(Date()).uppercase(),
                    color = Muted, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 1.sp
                )
                Text("Ready to train?", color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.ExtraBold)
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                StatCard(Icons.Rounded.LocalFireDepartment, "${streak(history)}", "Day streak", Accent, Modifier.weight(1f))
                StatCard(Icons.Rounded.FitnessCenter, "${week.size}", "This week", Color(0xFF7C4DFF), Modifier.weight(1f))
                StatCard(Icons.Rounded.Timer, "${week.sumOf { it.minutes }}", "Minutes", Color(0xFF00C853), Modifier.weight(1f))
            }
        }
        item {
            Column {
                SectionTitle("This week")
                WeekStrip(history)
            }
        }
        item {
            Column {
                SectionTitle("Today's pick")
                RoutineCard(pick, Modifier.fillMaxWidth(), height = 190.dp) { onOpen(pick) }
            }
        }
        item {
            Column {
                SectionTitle("Quick start")
                LazyRow(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    items(Library.all) { r ->
                        RoutineCard(r, Modifier.width(250.dp), height = 140.dp) { onOpen(r) }
                    }
                }
            }
        }
    }
}

@Composable
fun WeekStrip(history: List<Session>) {
    val start = remember { weekStart() }
    val days = remember(history) { history.map { dayKey(it.at) }.toSet() }
    val todayKey = remember { dayKey(System.currentTimeMillis()) }
    val labels = listOf("M", "T", "W", "T", "F", "S", "S")

    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(22.dp))
            .background(Panel)
            .padding(vertical = 16.dp, horizontal = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        for (i in 0..6) {
            val c = Calendar.getInstance().apply {
                timeInMillis = start
                add(Calendar.DAY_OF_YEAR, i)
            }
            val key = dayKey(c.timeInMillis)
            val done = key in days
            val isToday = key == todayKey
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(labels[i], color = Muted, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                Box(
                    Modifier
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(
                            if (done) Brush.linearGradient(listOf(Accent2, Accent))
                            else Brush.linearGradient(listOf(Panel2, Panel2))
                        )
                        .then(if (isToday && !done) Modifier.border(2.dp, Accent, CircleShape) else Modifier),
                    contentAlignment = Alignment.Center
                ) {
                    if (done) {
                        Icon(Icons.Rounded.Check, null, tint = Color.White, modifier = Modifier.size(20.dp))
                    } else {
                        Text(
                            "${c.get(Calendar.DAY_OF_MONTH)}",
                            color = if (isToday) Color.White else Muted,
                            fontSize = 13.sp
                        )
                    }
                }
            }
        }
    }
}

// ---------- Workouts list ----------

@Composable
fun WorkoutsScreen(pad: PaddingValues, onOpen: (Routine) -> Unit) {
    LazyColumn(
        contentPadding = PaddingValues(
            start = 20.dp, end = 20.dp,
            top = pad.calculateTopPadding() + 24.dp,
            bottom = pad.calculateBottomPadding() + 24.dp
        ),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Column(Modifier.padding(bottom = 4.dp)) {
                Text("Workouts", color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.ExtraBold)
                Text("No equipment needed", color = Muted, fontSize = 14.sp)
            }
        }
        items(Library.all) { r ->
            RoutineCard(r, Modifier.fillMaxWidth(), height = 170.dp) { onOpen(r) }
        }
    }
}

// ---------- History ----------

@Composable
fun HistoryScreen(history: List<Session>, pad: PaddingValues) {
    val fmt = remember { SimpleDateFormat("EEE, MMM d · h:mm a", Locale.getDefault()) }
    if (history.isEmpty()) {
        Column(
            Modifier
                .fillMaxSize()
                .padding(pad)
                .padding(40.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(Icons.Rounded.EmojiEvents, null, tint = Panel2, modifier = Modifier.size(96.dp))
            Spacer(Modifier.height(16.dp))
            Text("No workouts yet", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text(
                "Finish your first session and it will show up here.",
                color = Muted, fontSize = 14.sp, textAlign = TextAlign.Center
            )
        }
        return
    }
    LazyColumn(
        contentPadding = PaddingValues(
            start = 20.dp, end = 20.dp,
            top = pad.calculateTopPadding() + 24.dp,
            bottom = pad.calculateBottomPadding() + 24.dp
        ),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("History", color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(bottom = 8.dp))
        }
        items(history) { s ->
            val r = Library.all.firstOrNull { it.name == s.routine }
            Row(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(Panel)
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    Modifier
                        .size(46.dp)
                        .clip(CircleShape)
                        .background(Brush.linearGradient(listOf(r?.c1 ?: Accent, r?.c2 ?: Accent2))),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(r?.icon ?: Icons.Rounded.FitnessCenter, null, tint = Color.White, modifier = Modifier.size(24.dp))
                }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(s.routine, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    Text(fmt.format(Date(s.at)), color = Muted, fontSize = 12.sp)
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text("${s.minutes} min", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                    Text("${s.sets} sets", color = Muted, fontSize = 12.sp)
                }
            }
        }
    }
}

// ---------- Routine detail ----------

@Composable
fun RoutineDetail(routine: Routine, onBack: () -> Unit, onStart: () -> Unit) {
    Column(Modifier.fillMaxSize().background(Bg)) {
        Box(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(bottomStart = 32.dp, bottomEnd = 32.dp))
                .background(Brush.linearGradient(listOf(routine.c1, routine.c2)))
        ) {
            Icon(
                routine.icon, null,
                tint = Color.White.copy(alpha = 0.16f),
                modifier = Modifier
                    .size(200.dp)
                    .align(Alignment.BottomEnd)
                    .offset(x = 30.dp, y = 30.dp)
            )
            Column(
                Modifier
                    .statusBarsPadding()
                    .padding(horizontal = 12.dp, vertical = 8.dp)
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Rounded.ArrowBack, null, tint = Color.White)
                }
                Column(Modifier.padding(start = 8.dp, end = 8.dp, top = 20.dp, bottom = 20.dp)) {
                    Text(routine.name, color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.ExtraBold)
                    Text(routine.tagline, color = Color.White.copy(alpha = 0.9f), fontSize = 15.sp)
                    Spacer(Modifier.height(16.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Pill("${routine.minutes} min")
                        Pill(routine.level)
                        Pill("${routine.totalSets} sets")
                    }
                }
            }
        }

        LazyColumn(
            Modifier.weight(1f),
            contentPadding = PaddingValues(20.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            itemsIndexed(routine.exercises) { i, e ->
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(18.dp))
                        .background(Panel)
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(Brush.linearGradient(listOf(routine.c1, routine.c2))),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("${i + 1}", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text(e.name, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                        Text(e.tip, color = Muted, fontSize = 12.sp)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text("${e.sets} × ${e.amount}", color = Color.White, fontWeight = FontWeight.Bold)
                        Text(e.unit, color = Muted, fontSize = 12.sp)
                    }
                }
            }
        }

        GradientButton(
            "Start workout",
            listOf(routine.c1, routine.c2),
            Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 20.dp, vertical = 12.dp),
            icon = Icons.Rounded.PlayArrow,
            onClick = onStart
        )
    }
}

// ---------- Active workout ----------

private fun clock(sec: Int) = String.format(Locale.US, "%d:%02d", sec / 60, sec % 60)

@Composable
fun ActiveWorkout(routine: Routine, onExit: () -> Unit, onSave: (Session) -> Unit) {
    var exIdx by remember { mutableIntStateOf(0) }
    var setIdx by remember { mutableIntStateOf(0) }
    var resting by remember { mutableStateOf(false) }
    var rest by remember { mutableIntStateOf(0) }
    var restTotal by remember { mutableIntStateOf(1) }
    var setsDone by remember { mutableIntStateOf(0) }
    var elapsed by remember { mutableIntStateOf(0) }
    var done by remember { mutableStateOf(false) }
    var confirmExit by remember { mutableStateOf(false) }

    BackHandler { if (done) onExit() else confirmExit = true }

    LaunchedEffect(done) {
        while (!done) {
            delay(1000)
            elapsed++
        }
    }
    LaunchedEffect(resting) {
        if (resting) {
            while (rest > 0) {
                delay(1000)
                rest--
            }
            resting = false
        }
    }

    val ex = routine.exercises[exIdx]
    val colors = listOf(routine.c1, routine.c2)

    fun completeSet() {
        setsDone++
        val lastSet = setIdx == ex.sets - 1
        val lastEx = exIdx == routine.exercises.lastIndex
        if (lastSet && lastEx) {
            done = true
            return
        }
        rest = ex.rest
        restTotal = ex.rest.coerceAtLeast(1)
        if (lastSet) {
            exIdx++
            setIdx = 0
        } else {
            setIdx++
        }
        resting = true
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(routine.c1.copy(alpha = 0.28f), Bg, Bg)))
    ) {
        if (done) {
            Column(
                Modifier
                    .fillMaxSize()
                    .systemBarsPadding()
                    .padding(28.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(Icons.Rounded.EmojiEvents, null, tint = Accent2, modifier = Modifier.size(110.dp))
                Spacer(Modifier.height(12.dp))
                Text("Workout complete", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
                Text(routine.name, color = Muted, fontSize = 16.sp)
                Spacer(Modifier.height(32.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    StatCard(Icons.Rounded.Timer, clock(elapsed), "Time", Accent, Modifier.weight(1f))
                    StatCard(Icons.Rounded.Check, "$setsDone", "Sets", Color(0xFF00C853), Modifier.weight(1f))
                    StatCard(Icons.Rounded.FitnessCenter, "${routine.exercises.size}", "Moves", Color(0xFF7C4DFF), Modifier.weight(1f))
                }
                Spacer(Modifier.height(32.dp))
                GradientButton(
                    "Save workout", colors, Modifier.fillMaxWidth(), icon = Icons.Rounded.Check
                ) {
                    onSave(Session(routine.name, (elapsed / 60).coerceAtLeast(1), setsDone, System.currentTimeMillis()))
                }
                TextButton(onClick = onExit) { Text("Discard", color = Muted) }
            }
        } else {
            Column(
                Modifier
                    .fillMaxSize()
                    .systemBarsPadding()
                    .padding(horizontal = 24.dp, vertical = 12.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { confirmExit = true }) {
                        Icon(Icons.Rounded.Close, null, tint = Color.White)
                    }
                    Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(routine.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        Text(clock(elapsed), color = Muted, fontSize = 13.sp)
                    }
                    Spacer(Modifier.size(48.dp))
                }
                Spacer(Modifier.height(8.dp))
                LinearProgressIndicator(
                    progress = { setsDone / routine.totalSets.toFloat() },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .clip(RoundedCornerShape(50)),
                    color = routine.c2,
                    trackColor = Panel2
                )

                Column(
                    Modifier.weight(1f),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    if (resting) {
                        Text("REST", color = Accent2, fontSize = 14.sp, fontWeight = FontWeight.Bold, letterSpacing = 4.sp)
                        Spacer(Modifier.height(16.dp))
                        Ring(rest / restTotal.toFloat(), 260.dp, 18.dp) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("$rest", color = Color.White, fontSize = 76.sp, fontWeight = FontWeight.ExtraBold)
                                Text("seconds", color = Muted, fontSize = 14.sp)
                            }
                        }
                        Spacer(Modifier.height(24.dp))
                        Column(
                            Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(20.dp))
                                .background(Panel)
                                .padding(16.dp)
                        ) {
                            Text("UP NEXT", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                            Text(ex.name, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                            Text(
                                "Set ${setIdx + 1} of ${ex.sets} · ${ex.amount} ${ex.unit}",
                                color = Muted, fontSize = 13.sp
                            )
                        }
                        Spacer(Modifier.height(12.dp))
                        Box(
                            Modifier
                                .clip(RoundedCornerShape(50))
                                .background(Panel2)
                                .clickable {
                                    rest += 15
                                    restTotal += 15
                                }
                                .padding(horizontal = 22.dp, vertical = 10.dp)
                        ) {
                            Text("+15 sec", color = Color.White, fontWeight = FontWeight.SemiBold)
                        }
                    } else {
                        Text(
                            "EXERCISE ${exIdx + 1} OF ${routine.exercises.size}",
                            color = Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp
                        )
                        Spacer(Modifier.height(6.dp))
                        Text(
                            ex.name, color = Color.White, fontSize = 32.sp,
                            fontWeight = FontWeight.ExtraBold, textAlign = TextAlign.Center
                        )
                        Text(ex.tip, color = Muted, fontSize = 14.sp, textAlign = TextAlign.Center)
                        Spacer(Modifier.height(28.dp))
                        Ring(setIdx / ex.sets.toFloat(), 260.dp, 18.dp) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("${ex.amount}", color = Color.White, fontSize = 76.sp, fontWeight = FontWeight.ExtraBold)
                                Text(ex.unit, color = Muted, fontSize = 16.sp)
                            }
                        }
                        Spacer(Modifier.height(20.dp))
                        Text(
                            "Set ${setIdx + 1} of ${ex.sets}",
                            color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                if (resting) {
                    GradientButton("Skip rest", colors, Modifier.fillMaxWidth(), icon = Icons.Rounded.SkipNext) {
                        resting = false
                    }
                } else {
                    GradientButton("Complete set", colors, Modifier.fillMaxWidth(), icon = Icons.Rounded.Check) {
                        completeSet()
                    }
                }
            }
        }
    }

    if (confirmExit) {
        AlertDialog(
            onDismissRequest = { confirmExit = false },
            containerColor = Panel,
            title = { Text("End workout?", color = Color.White) },
            text = { Text("Your progress for this session won't be saved.", color = Muted) },
            confirmButton = {
                TextButton(onClick = { confirmExit = false; onExit() }) { Text("End", color = Accent) }
            },
            dismissButton = {
                TextButton(onClick = { confirmExit = false }) { Text("Keep going", color = Color.White) }
            }
        )
    }
}
